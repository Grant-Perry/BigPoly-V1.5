import SwiftUI
import MapKit
import HealthKit

struct FullMapView: View {
   let workout: HKWorkout
   @ObservedObject var polyViewModel: PolyViewModel

   @State private var routeCoordinates: [CLLocationCoordinate2D] = []
   @State private var cityName: String = "Fetching..."
   @State private var workoutDate: Date = Date()
   @State private var distance: Double = 0.0
   @State private var isError: Bool = false
   @State private var errorMessage: String = ""
   @State private var mapType: MKMapType = .standard

   var body: some View {
	  VStack {
		 Picker("Map Type", selection: $mapType) {
			Text("Standard").tag(MKMapType.standard)
			Text("Satellite").tag(MKMapType.satellite)
		 }
		 .pickerStyle(SegmentedPickerStyle())
		 .padding()

		 if isError {
			Text(errorMessage)
			   .font(.system(size: 17))
			   .foregroundColor(.red)
			   .frame(maxWidth: .infinity, alignment: .center)
		 } else {
			if !routeCoordinates.isEmpty {
			   GradientMapView(coordinates: routeCoordinates, mapType: $mapType)
				  .onAppear {
					 // Optionally handle map region updates if needed
				  }
			} else {
			   Text("No route data available.")
				  .foregroundColor(.gray)
			}
		 }
	  }
	  .onAppear {
		 Task {
			do {
			   if let fetchedRoute = await polyViewModel.fetchDetailedRouteData(for: workout) {
				  routeCoordinates = fetchedRoute
			   } else {
				  throw NSError(domain: "com.BigPoly", code: 404, userInfo: [NSLocalizedDescriptionKey: "No route data found."])
			   }

			   cityName = await polyViewModel.fetchCityName(for: workout) ?? "Unknown City"
			   distance = await polyViewModel.fetchDistance(for: workout) ?? 0
			   workoutDate = workout.startDate
			} catch {
			   isError = true
			   errorMessage = error.localizedDescription
			   print("Error fetching data: \(error.localizedDescription)")
			}
		 }
	  }
	  .safeAreaInset(edge: .top) {
		 if !isError {
			WorkoutMetricsView(cityName: cityName,
							   workoutDate: workoutDate,
							   distance: distance)
		 }
	  }
	  .navigationTitle("Workout Map")
	  .navigationBarTitleDisplayMode(.inline)
   }
}
